void print_hello();

int main() {
	print_hello();
	return 0;
}
