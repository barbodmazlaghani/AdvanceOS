#include <stdio.h>

void print_hello() {
	printf("hello world!\n");
	return;
}
