#include <iostream>
#include <thread>
#include <atomic>

std::atomic<bool> flag[2];
std::atomic<int> turn;
int a = 0;  

void lock(int thread) {
    flag[thread] = true;
    turn = 1 - thread;
    while (flag[1 - thread] && turn == 1 - thread) {
    }
}

void unlock(int thread) {
    flag[thread] = false;
}

void threadFunction(int thread) {
    for (int i = 0; i < 1000; ++i) {
        lock(thread);
        ++a;
        unlock(thread);
    }
}

int main() {
    std::thread t1(threadFunction, 0);
    std::thread t2(threadFunction, 1);

    t1.join();
    t2.join();

    std::cout << "Final value of a: " << a << std::endl;
    return 0;
}
