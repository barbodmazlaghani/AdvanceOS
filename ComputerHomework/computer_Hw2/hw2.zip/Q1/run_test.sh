#!/bin/bash

g++ -o peterson_lock peterson_lock.cpp -pthread
echo "Compiled Peterson's lock program."

g++ -o ticket_lock ticket_lock.cpp -pthread
echo "Compiled Ticket lock program."

echo "Running Peterson's lock test..."
for i in $(seq 1 100); do
    ./peterson_lock
done

echo "Running Ticket lock test..."
for i in $(seq 1 100); do
    ./ticket_lock
done
