#include <iostream>
#include <thread>
#include <atomic>

std::atomic_int next_ticket(0);
std::atomic_int now_serving(0);
int b = 0;

void ticketLock_acquire() {
    int my_ticket = next_ticket.fetch_add(1, std::memory_order_seq_cst);
    while (now_serving.load(std::memory_order_seq_cst) != my_ticket) {
    }
}

void ticketLock_release() {
    now_serving.fetch_add(1, std::memory_order_seq_cst);
}

void ticketThreadFunction() {
    for (int i = 0; i < 1000; ++i) {
        ticketLock_acquire();
        ++b;
        ticketLock_release();
    }
}

int main() {
    std::thread t1(ticketThreadFunction);
    std::thread t2(ticketThreadFunction);

    t1.join();
    t2.join();

    std::cout << "Final value of b: " << b << std::endl;
    return 0;
}
