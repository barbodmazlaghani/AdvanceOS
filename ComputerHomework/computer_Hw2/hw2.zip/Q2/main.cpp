#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>
#include <thread>
#include <mutex>
#include <atomic>
#include <sstream>
#include <chrono>
#include <ctime>
#include <x86intrin.h>

using namespace std;

class TicketLock {
public:
    atomic<int> next_ticket{0};
    atomic<int> now_serving{0};

    void acquire() {
        int my_ticket = next_ticket.fetch_add(1);
        while (now_serving.load() != my_ticket) {
            // Active waiting
        }
    }

    void release() {
        now_serving.fetch_add(1);
    }
};

void reverseWords(string& input) {
    istringstream iss(input);
    string word;
    string result;
    while (iss >> word) {
        reverse(word.begin(), word.end());
        result += word + " ";
    }
    input = result.substr(0, result.length() - 1); // Remove the last space
}

void workerFunction(string& text, TicketLock& ticketLock, mutex& pthreadMutex, int lockType) {
    uint64_t start = __rdtsc();
    timespec time_start, time_end;
    clock_gettime(CLOCK_MONOTONIC, &time_start);

    if (lockType == 0) {
        lock_guard<mutex> lock(pthreadMutex);
        reverseWords(text);
    } else {
        ticketLock.acquire();
        reverseWords(text);
        ticketLock.release();
    }

    uint64_t end = __rdtsc();
    clock_gettime(CLOCK_MONOTONIC, &time_end);

    double elapsed = (time_end.tv_sec - time_start.tv_sec) * 1e9;
    elapsed = (elapsed + time_end.tv_nsec - time_start.tv_nsec) * 1e-9;

    cout << "Thread completed: CPU cycles (RDTSC): " << end - start << ", Elapsed time (clock_gettime): " << elapsed << " seconds\n";
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        cerr << "Usage: " << argv[0] << " <number_of_threads> <lock_type>\n";
        cerr << "       lock_type 0 for mutex, 1 for ticket lock\n";
        return 1;
    }

    string inputFile = "input.txt", outputFile = "output.txt";
    int threadCount = stoi(argv[1]);
    int lockType = stoi(argv[2]);

    ifstream inFile(inputFile);
    ofstream outFile(outputFile);
    stringstream buffer;
    buffer << inFile.rdbuf();
    string content = buffer.str();

    size_t partSize = content.size() / threadCount;
    vector<string> parts(threadCount);
    size_t pos = 0;
    for (int i = 0; i < threadCount - 1; ++i) {
        parts[i] = content.substr(pos, partSize);
        pos += partSize;
    }
    parts.back() = content.substr(pos);

    vector<thread> threads;
    TicketLock ticketLock;
    mutex pthreadMutex;

    auto start = chrono::high_resolution_clock::now();

    for (int i = 0; i < threadCount; ++i) {
        threads.emplace_back(workerFunction, ref(parts[i]), ref(ticketLock), ref(pthreadMutex), lockType);
    }

    for (auto& thread : threads) {
        thread.join();
    }

    auto finish = chrono::high_resolution_clock::now();
    chrono::duration<double> elapsed = finish - start;
    cout << "Overall elapsed time: " << elapsed.count() << " s\n";

    for (const auto& part : parts) {
        outFile << part << ' ';
    }

    return 0;
}
