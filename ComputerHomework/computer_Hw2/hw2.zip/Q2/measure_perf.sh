#!/bin/bash

if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <program_name>"
    exit 1
fi

program_name=$1

for i in {1..10}; do
    echo "Running with $i threads"
    perf stat -e cycles,instructions,cache-references,cache-misses,sched:sched_switch,sched:sched_stat_runtime,branch-misses,context-switches -o perf_output_$i.txt ./$program_name $i
done

echo "Performance measurement completed."
