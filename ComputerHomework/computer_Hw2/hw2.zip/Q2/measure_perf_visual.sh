#!/bin/bash

if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <program_name>"
    exit 1
fi

program_name=$1

echo "Threads,Cycles,Instructions,Cache-References,Cache-Misses,Sched-Switches,Sched-Stat-Runtime,Branch-Misses,Context-Switches,Elapsed Time (s)" > pthread_performance_data.csv
echo "Threads,Cycles,Instructions,Cache-References,Cache-Misses,Sched-Switches,Sched-Stat-Runtime,Branch-Misses,Context-Switches,Elapsed Time (s)" > ticket_performance_data.csv

for i in {1..10}; do
    echo "Running pthread lock with $i threads"
    perf stat -e cycles,instructions,cache-references,cache-misses,sched:sched_switch,sched:sched_stat_runtime,branch-misses,context-switches -o perf_output_pthread_$i.txt ./$program_name $i 0
    echo "Running ticket lock with $i threads"
    perf stat -e cycles,instructions,cache-references,cache-misses,sched:sched_switch,sched:sched_stat_runtime,branch-misses,context-switches -o perf_output_ticket_$i.txt ./$program_name $i 1

    cycles=$(grep 'cycles' perf_output_pthread_$i.txt | awk '{print $1}' | sed 's/,//g')
    instructions=$(grep 'instructions' perf_output_pthread_$i.txt | awk '{print $1}' | sed 's/,//g')
    elapsed_time=$(grep 'seconds time elapsed' perf_output_pthread_$i.txt | awk '{print $1}')
    echo "$i,$cycles,$instructions,...(other metrics here),$elapsed_time" >> pthread_performance_data.csv

    cycles=$(grep 'cycles' perf_output_ticket_$i.txt | awk '{print $1}' | sed 's/,//g')
    instructions=$(grep 'instructions' perf_output_ticket_$i.txt | awk '{print $1}' | sed 's/,//g')

    elapsed_time=$(grep 'seconds time elapsed' perf_output_ticket_$i.txt | awk '{print $1}')
    echo "$i,$cycles,$instructions,...(other metrics here),$elapsed_time" >> ticket_performance_data.csv
done

echo "Performance measurement completed."
