#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"
#include <stddef.h>

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return wait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int n;

  argint(0, &n);
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

int
sys_send(void)
{
  int s_id, r_id; 
  char *message[MSG_SIZE];

  argstr(2, message, MSG_SIZE);

  argint(0, &s_id);
  argint(1, &r_id);
  
  send_message(s_id, r_id, message);

  return 0;
}

int sys_recv(void)
{
  int addr;
  argint(0, &addr); 

  receive_message(addr);
  return 0;
}
int sys_call(void) {
    int sbuf_len, rbuf_len, pid;
    char *sbuf, *rbuf;

    // Extract system call arguments directly without error checks here 
    argint(0, &sbuf_len);
    argint(1, &rbuf_len);
    argaddr(2, (uint64*)&sbuf);
    argaddr(3, (uint64*)&rbuf);
    argint(4, &pid);

    // Validate the arguments
    if (sbuf_len < 0 || rbuf_len < 0 || sbuf == NULL || rbuf == NULL || pid < 0) {
        return -1;  // Return error if any argument is invalid
    }

    // Call send and recv functions (Assuming these functions are defined and handle errors internally)
    if (send_message(sbuf_len, sbuf, pid) < 0 || receive_message(rbuf) < 0) {
        return -1;  // Return error if send or recv fails
    }

    return 0;  // Success
}
int sys_rrnext(void) {
    int sbuf_len, rbuf_len;
    char *sbuf, *rbuf;

    // Extract system call arguments
    argint(0, &sbuf_len);
    argint(1, &rbuf_len);
    argaddr(2, (uint64*)&sbuf);
    argaddr(3, (uint64*)&rbuf);

    // Validate the arguments
    if (sbuf_len < 0 || rbuf_len < 0 || sbuf == NULL || rbuf == NULL) {
        return -1;  // Return error if any argument is invalid
    }

    // Call recv and then send functions
    if (receive_message(sbuf) < 0 || send_message(rbuf_len, rbuf, 0) < 0) {  
        return -1;  // Return error if recv or send fails
    }

    return 0;  // Success
}


