#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define MAX_MSG 128

int main(void) {
    char sbuf[MAX_MSG] = "Message from sender";
    char rbuf[MAX_MSG] = {0};
    char response_msg[MAX_MSG] = "Response from parent";

    int pid = fork();
    if (pid == 0) {
        // Child process: wait for a message and then respond using the parent's PID known from fork
        if (rrnext(sizeof(sbuf), sizeof(response_msg), sbuf, response_msg) < 0) {
            printf("Child: rrnext failed\n");
        } else {
            printf("Child received request: %s, sent response\n", sbuf);
        }
        exit(0);
    } else {
        // Parent process: send a message and wait for the response
        sleep(1);  // Small delay to ensure child is waiting
        if (call(sizeof(sbuf), sizeof(rbuf), sbuf, rbuf, pid) < 0) {
            printf("Parent: call failed\n");
        } else {
            printf("Parent received response: %s\n", rbuf);
        }
        wait(0);
    }

    exit(0);
}


