#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(void) {
    char sbuf[100] = "Hello, this is a message from the sender.";
    char rbuf[100] = {0};

    if(fork() == 0) {
        // Child process: calls and sends a message, expects a response
        sys_call(sizeof(sbuf), sizeof(rbuf), sbuf, rbuf, getppid());
        printf("Child received response: %s\n", rbuf);
        exit(0);
    } else {
        // Parent process: waits for a message and sends a response
        sys_rrnext(sizeof(sbuf), sizeof(rbuf), sbuf, rbuf);
        printf("Parent received request: %s\n", sbuf);
        strcpy(rbuf, "Hello, this is a response from the parent.");
        wait(0);
    }
    exit(0);
}
